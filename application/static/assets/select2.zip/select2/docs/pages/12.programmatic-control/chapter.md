---
title: Programmatic control
metadata:
    description: Programmatically adding and selecting items, getting the current selections, manipulating the control, and working with Select2 events.
taxonomy:
    category: docs
---

# Programmatic control
